<?php
return array (
  0 => '主题设置,/template/MDLutu/admin/',
  1 => '播放器设置,/addons/dplayer/system.php',
);